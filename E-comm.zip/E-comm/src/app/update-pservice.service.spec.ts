import { TestBed, inject } from '@angular/core/testing';

import { UpdatePserviceService } from './update-pdetails/update-pservice.service';

describe('UpdatePserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UpdatePserviceService]
    });
  });

  it('should be created', inject([UpdatePserviceService], (service: UpdatePserviceService) => {
    expect(service).toBeTruthy();
  }));
});
