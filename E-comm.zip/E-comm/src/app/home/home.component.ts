import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { count } from 'rxjs/operator/count';
declare var $ :any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

obj:any;
 

  constructor(private aut:AuthService) { }

  ngOnInit() {  
    this.obj=(sessionStorage.getItem("obj"))
    if(this.aut.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }	 
  }
  
}




