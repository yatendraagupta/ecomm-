import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { RegisterService } from './register/register.service';
import { ProductDetailsService } from './product-details/product-details.service';
import { LoginService } from './login/login.service';
import { HomeService } from './home/home.service';
import { CheckoutService } from './checkout/checkout.service';
import { CartService } from './cart/cart.service';
import { AboutUsService } from './about-us/about-us.service';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentService } from './payment/payment.service';
import { AuthService } from './auth.service';
import { AuthGuard } from './auth.guard';
import { AdminComponent } from './admin/admin.component';
import { ProfileComponent } from './profile/profile.component';
import { AdcComponent } from './adc/adc.component';
import { ChangerComponent } from './changer/changer.component';
import { BillComponent } from './bill/bill.component';
import { WalletComponent } from './wallet/wallet.component';
import { ReviewComponent } from './review/review.component';
import { AdminGuard } from './auth/admin.guard';
import { UpdateProductComponent } from './update-product/update-product.component';
import { UpdatePDetailsComponent } from './update-pdetails/update-pdetails.component';
import { AddProductComponent } from './add-product/add-product.component';
import { ViewReviewComponent } from './view-review/view-review.component';
import { UpdatePserviceService } from './update-pdetails/update-pservice.service';
import { UpdateProductService } from './update-product/update-product.service';























@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    CartComponent,
    CheckoutComponent,
    ProductDetailsComponent,
    AboutUsComponent,
    ProductDisplayComponent,
    PaymentComponent,
    AdminComponent,
    ProfileComponent,
    AdcComponent,
    ChangerComponent,
    BillComponent,
    WalletComponent,
    ReviewComponent,
    UpdateProductComponent,
   UpdatePDetailsComponent,
    AddProductComponent,
    ViewReviewComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule

  ],
  providers: [AuthService,AdminGuard,AuthGuard,PaymentService,RegisterService,ProductDetailsService,LoginService,HomeService,CheckoutService,CartService,AboutUsService,UpdatePserviceService,UpdateProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
