import { Component, OnInit } from '@angular/core';
import { AllProducts } from '../model/allProducts';
import { ProductDetailsService } from '../product-details/product-details.service';
import { AuthService } from '../auth.service';
import { UpdateProductService } from './update-product.service';
import { LoginService } from '../login/login.service';


@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {

  ohd: string;
  prod3(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  prod2: any;
  errorMessage:string;
  prod : AllProducts[];
  prod1:AllProducts[];
  flag:boolean=true;
 upFlag:boolean;
 data:any;
  obj: string;
  constructor(private product1:ProductDetailsService,private up:UpdateProductService,private ser:LoginService ,private aut:AuthService) { }

  ngOnInit() {

   
 
  if(this.aut.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }
    // this.obj=(sessionStorage.getItem("obj"))
    // this.product1.getAllProduct()
    // .then(res => {this.prod = res
    // console.log(this.prod)})
    //  .catch(error => {this.errorMessage = error.message; }); 
    //  if(this.aut.sho==true){
    //   document.getElementById("main").style.marginLeft = "250px";
    //  }
    //  else{
    //   document.getElementById("main").style.marginLeft = "0";
    //  }
    this.ser.draw().
then(res=>{
  this.data=res.message;
})
.catch(err=>err)  
  

    this.product1.getAllProduct()
    .then(res => {this.prod = res
    console.log(this.prod)})
     .catch(error => {this.errorMessage = error.message; }); 
     if(this.aut.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }
  }
 
// remove(data){
//     this.up.delProd(data)
//  }

 
remove(i){

  this.up.delProd(i)
  .then(res => {  

    sessionStorage.setItem('delete',JSON.stringify(res))
   location.reload();
  })
  .catch(error => this.errorMessage = error.message);
 }

}
