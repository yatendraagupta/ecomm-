import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { CompileMetadataResolver } from '@angular/compiler';

@Injectable()
export class UpdatePserviceService {

  constructor(private http:Http) { }


 
  upProduct(data){
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/updateProduct",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }
  addProduct(data1,data2){
  
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/addProduct/"+data2,data1)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }

}
