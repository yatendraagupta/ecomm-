import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePDetailsComponent } from './update-pdetails.component';

describe('UpdatePDetailsComponent', () => {
  let component: UpdatePDetailsComponent;
  let fixture: ComponentFixture<UpdatePDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatePDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
