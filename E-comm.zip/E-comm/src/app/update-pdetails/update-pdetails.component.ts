import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,Validators } from '@angular/forms';
import {Router} from '@angular/router';
import { UpdatePserviceService } from './update-pservice.service';
import { AuthService } from '../auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-update-pdetails',
  templateUrl: './update-pdetails.component.html',
  styleUrls: ['./update-pdetails.component.css']
})
export class UpdatePDetailsComponent implements OnInit {
  UpdateForm:FormGroup;
  errorMessage: any;
  prod: any;
  constructor(private fb:FormBuilder, private ss:UpdatePserviceService, private router:Router   ,private aut:AuthService) { }

  ngOnInit() {
 
    if(this.aut.sho==true){
        document.getElementById("main").style.marginLeft = "250px";
       }
       else{
        document.getElementById("main").style.marginLeft = "0";
       }
    this.UpdateForm=this.fb.group({
      name:["",[Validators.required,Validators.pattern("[A-Za-z ]+") ]],
      price:["",[Validators.required,Validators.min(0),Validators.pattern("[0-9]+")]],
      productId:["",[Validators.required,Validators.pattern("[0-9]{4}")]],
     // stock:["",[Validators.required,Validators.min(0),Validators.pattern("[0-9]+")]],
      description:["",[Validators.required,Validators.minLength(5)]]
      
    })
  }
  update(){
    console.log(this.UpdateForm.value)
    this.ss.upProduct(this.UpdateForm.value)
    .then(res => {this.prod=res
      this.router.navigateByUrl('/viewProduct');
      
 Swal.fire({
  type: 'success',
  title: 'Product is updated',
  showConfirmButton: false,
  timer: 900
})
    })
    .catch(error => this.errorMessage = error.message);
    
  }

}
