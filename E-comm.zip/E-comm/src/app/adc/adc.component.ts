import { Component, OnInit } from '@angular/core';

import { FormBuilder, Validators} from '@angular/forms';

import { LoginService } from '../login/login.service';
import { User } from '../model/user';
import { FormGroup } from '@angular/forms/src/model';
import { Router } from '@angular/router';
import { Review } from '../model/review';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-adc',
  templateUrl: './adc.component.html',
  styleUrls: ['./adc.component.css']
})
export class AdcComponent implements OnInit {
flag1:boolean;
flag2:boolean;
flag3:boolean;
//reviewForm:FormGroup
userId:number;
name:string;
userName:string;
emaill:string;
mobileNumber:number;
//rev:Review[];
user3:User[];
errorMessage:string;
  

sellerval:String="none";
  constructor(private fb:FormBuilder,private as:LoginService, private router:Router ,private authServe:AuthService) { }
  viewUser(){ 
    this.flag2=false;
    this.flag3=false;
    this.flag1=true;
  }
  upProd(){ 
    this.flag2=false;
    this.flag3=true;
    this.flag1=false;
  }
  review(){ 
    this.flag2=true;
    this.flag3=false;
    this.flag1=false;
  }
  //------------------------------------------------------------------------
 
  ngOnInit() {
    if(this.authServe.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }	

    this.as.viewUser1()
    .then(
     (user3) => {
       this.user3 = user3
      }
    )
    .catch(
      (error) => {
         this.errorMessage = error.message;
       }
    );
    
    
  }
}
