import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { CardDetails } from '../product-details/product';

@Injectable()
export class PaymentService {
 
  constructor(private http:Http) { }

 

  transaction(data) {
    return this.http.get("http://localhost:8765/furn_BACKEND/FurnicoApi/transactionWallet",data)
    .toPromise()
    .then(Resp=>Resp.json() as CardDetails)
    .catch(error=>Promise.reject(error.json() ||error));
  }


  pay(data){
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/AddCard ",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  } 



  getcard(data){
    return this.http.get("http://localhost:8765/furn_BACKEND/FurnicoApi/getCard/"+data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  } 



  addCard(data){
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/AddCard",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }

  updateCa(data){
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/updateCard",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }

  payM(data){
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/transactionWallet",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }
}  
