import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PaymentService } from './payment.service';
import { CardDetails } from '../product-details/product';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { JSONPBackend } from '@angular/http';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  
  auth:boolean=false;
  PaymentForm:FormGroup; 
  showOnline=false;
  showOffline=false;
  addC: boolean;
  show: boolean;
  card: CardDetails;
  errorMessage: any;
  total: any;
  userI: string;
  CurrentTime1: string;
  up: boolean=false;
  updatecard: FormGroup; 
  qwee: any;
  upd: any;
  showW: boolean;
  wal: boolean;
  money: string;
  button: boolean=false;


  tru={
    "userId": 2101,
    "balance": 5000
}

  constructor(private fb:FormBuilder ,private router:Router,private ps:PaymentService,private aut:AuthService) { }

  ngOnInit() {

    
 
  if(this.aut.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }
    this.PaymentForm=this.fb.group({
      userId:[""],
      nameOnCard:["",[Validators.required,Validators.minLength(3),Validators.pattern("([A-Za-z]+ {0,1})+")]],
      expiryMonth:["",[Validators.required]],
      expiryYear:["",[Validators.required]],
      cardType:["",[Validators.required]],
      cardNumber:["",[Validators.required,Validators.pattern("[0-9]{16}")]],
      cvv:["",[Validators.required,Validators.pattern("[1-9][0-9]{2}")]]
  })


this.updatecard=this.fb.group({
  userId:[""],
  nameOnCard:["",[Validators.required,Validators.minLength(3),Validators.pattern("([A-Za-z]+ {0,1})+")]],
  expiryMonth:["",[Validators.required,Validators.min(1),Validators.max(12)]],
  expiryYear:["",[Validators.required,Validators.min(2020),Validators.max(2040)]],
  cardType:["",[Validators.required]],
  cardNumber:["",[Validators.required,Validators.pattern("[1-9][0-9]{15}")]],
  cvv:["",[Validators.required,Validators.pattern("[1-9][0-9]{2}")]]
})

  this.total=sessionStorage.getItem('total');
  this.money=sessionStorage.getItem('money')
  this.userI=JSON.parse(sessionStorage.getItem('useri'));
  }
  public payment=false
  
  pay(){
    this.ps.pay(this.PaymentForm.value)
    setTimeout(() => {
      this.payment = true
    }, 300)
  }

  online(){
    this.showOnline=true;
  }

  offline(){
    this.auth=true;
    this.showOnline=false;
    Swal.fire({
      type: 'success',
      title: 'your order had been placed',
      showConfirmButton: false,
      timer: 1200
    })
    setTimeout(() => {
      this.router.navigate(['/bill'])
    }
    , 1050);
   
  }

  addCard(){
    this.addC=true;
    this.show=false;
    this.PaymentForm.value.userId=this.userI
    this.ps.addCard(this.PaymentForm.value)
    .then(res=>{this.card=res
      this.offline()
    })
    .catch(error => {this.errorMessage = error.message;});
  }

  showCard()
  {
    this.show=true;
    this.showW=false;
    this.wal=false;
    this.addC=false; 
    this.ps.getcard(this.userI)
    .then(res=>this.card=res)
    .catch(error => {this.errorMessage = error.message; });
  }

  showwallet()
  {
    this.show=false;
    this.addC=false;
    this.wal=true;
   
    if(this.money < this.total){
this.button=true;
    }else{
      this.button=false;
    }
  }

  update(){
    this.up=true;
    this.show=true;
  }

  updateCa(){
this.updatecard.value.userId=this.userI
this.updatecard.value.cvv=JSON.parse(this.updatecard.value.cvv)
this.updatecard.value.cardNumber=JSON.stringify(this.updatecard.value.cardNumber)
this.qwee=this.updatecard.value
    this.ps.updateCa(this.qwee)
    .then(res=>{this.upd=res})
    .catch(error => {this.errorMessage = error.message; });
    location.reload()
  }


  payM(){
    this.tru.userId=JSON.parse(this.userI);
    this.tru.balance=JSON.parse(this.total);
    this.ps.payM(this.tru)
  //  console.log(JSON.stringify(this.tru))
    .then(res=>{this.upd=res})
    .catch(error => {this.errorMessage = error.message;});
    this.offline();
  }
}
