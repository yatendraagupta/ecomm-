import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class AuthService {
  sho: boolean=false;
  adminLoginFlag: boolean = true;
 

  constructor(private http:Http) { }

  sendToken(token: string) {
    sessionStorage.setItem("LoggedInUser", token)
  }
  getToken() {
    return sessionStorage.getItem("LoggedInUser")
  }
  isLoggednIn() {
    return this.getToken() !== null;
  }
  openNav() {
    this.sho=true;
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  closeNav() {
    this.sho=false;
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
  }

  checkAdmin():boolean{
    if(sessionStorage.getItem('username')=='shru1@gmail.com'){
      return false;
    }
    return true;
  }

  showcard1(data){
   
    return this.http.get('http://localhost:8765/furn_BACKEND/FurnicoApi/getCard/'+data)
    .toPromise()
    .then(response=> response.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }


  walletmoney1(data){
  
    return this.http.post('http://localhost:8765/furn_BACKEND/FurnicoApi/addWallet',data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }


rate(data){
    return this.http.post('http://localhost:8765/furn_BACKEND/FurnicoApi/addReview',data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
}


getreview(data){
  return this.http.get('http://localhost:8765/furn_BACKEND/FurnicoApi/topReviews/'+data)
  .toPromise()
  .then(Resp=>Resp.json() as any)
  .catch(error=>Promise.reject(error.json() ||error));  
}
}
