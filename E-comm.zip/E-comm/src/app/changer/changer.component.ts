import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../login/login.service';
import Swal from 'sweetalert2';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-changer',
  templateUrl: './changer.component.html',
  styleUrls: ['./changer.component.css']
})
export class ChangerComponent implements OnInit {
  pro:any;
  type:any;
  changePasswordForm:FormGroup;
  passwordmessage: string;
  oldPassFlag: boolean ;
  successMessage: any;
  obj: string;
  PasswordForm: FormGroup;
  obj1: string;
  errorMessage: any;
  eMail: string;

  constructor(private fb: FormBuilder,private router:Router,private lg:LoginService,private authServe:AuthService) { }

  ngOnInit() {
    if(this.authServe.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }
    this.obj=(sessionStorage.getItem("obj"));
    this.obj1=(sessionStorage.getItem("username"));
    this.pro=sessionStorage.getItem('password');
    this.eMail=sessionStorage.getItem('LoggedInUser');

    this.PasswordForm=this.fb.group({
      oldPass: ['',Validators.required]
    })

    this.changePasswordForm = this.fb.group({
      email: [''] ,
      password:  ['',Validators.required]
    })

  }
pass(){
    this.router.navigate(['profile'],{skipLocationChange:true }) 
}

chec() {
    this.oldPassFlag = false;
    if (this.PasswordForm.get('oldPass').value == this.pro) {
      this.oldPassFlag = true;
    }
  }


updatePassword(){
  this.changePasswordForm.value.email=this.eMail;
this.lg.changepass(this.changePasswordForm.value)
.then(res => {
  Swal.fire(
    "Woohoo!",
    "Password Updated Successfully ",
    'success'
  )
})
.catch(error => this.errorMessage = error.message);
this.router.navigate(['profile'])
}
}

