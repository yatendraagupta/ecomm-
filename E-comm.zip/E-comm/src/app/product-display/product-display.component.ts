import { Component, OnInit } from '@angular/core';
import { ActivatedRoute ,ParamMap} from '@angular/router';
import { ProductDetailsService } from '../product-details/product-details.service';
import { product } from '../product-details/product';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent implements OnInit {
  obj: string;
  prid: string;
  errorMessage: any;
  getProduct1: any;

  constructor(private route:ActivatedRoute,private ser:ProductDetailsService,private aut:AuthService) { }
  getProduct;
  product:any;
prod:product;
  ngOnInit() {
    if(this.aut.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }
    this.obj=(sessionStorage.getItem("obj"))
    this.route.queryParams.subscribe(params=>{
      this.product = JSON.parse(params.pid);
      this.aut.getreview(this.product.productId).
      then(res=>{this.getProduct1=res})
      .catch(err=>err)
    });
  }


  getProductById(pid)
  {
    this.ser.getProduct(pid)
    .then(res=>{this.prod=res
   
    })
    .catch(error => {this.errorMessage = error.message; })

  }

}
