import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  pro:any;
  type:any;
  changePasswordForm:FormGroup;
  passwordmessage: string;
  oldPassFlag: boolean = false;
  successMessage: any;
  obj: string;

  constructor(private fb: FormBuilder,private router:Router,private aut:AuthService) { }

  ngOnInit() {

    if(this.aut.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }

    this.obj=(sessionStorage.getItem("obj"))
    this.pro=JSON.parse(sessionStorage.getItem('user'));
    // this.type=JSON.parse(localStorage.getItem('isLoggedin'));
    // console.log(this.type)
    console.log(this.pro)

    this.changePasswordForm = this.fb.group({
      oldPass: ['',Validators.required],
      password: ['',[Validators.required,Validators.minLength(6),Validators.pattern("[A-Za-z0-9]*[_]{1}[A-Za-z0-9]*")]],
      confirmPass: ['',Validators.required] ,
      email: [this.pro.email]
    })

  }
  pass(){
    this.router.navigate(['change'],{skipLocationChange:true })
  }
  
  change()
  {
    if(this.changePasswordForm.get('password').value!=this.changePasswordForm.get('confirmPass').value)
    {
      this.passwordmessage="password not matched!";
    }
    else if(this.changePasswordForm.get('password').value==this.changePasswordForm.get('confirmPass').value)
    {
      this.passwordmessage=null;
    }
  }

  checkOldPass(){
  
    if(this.changePasswordForm.get('oldPass').value!=JSON.parse(localStorage.getItem('loginSessUser')).password)
    {
      this.oldPassFlag = false;
    }
    else if(this.changePasswordForm.get('oldPass').value==JSON.parse(localStorage.getItem('loginSessUser')).password)
    {
      this.oldPassFlag = true;
    }
  }

  changePassword(){
    this.successMessage = null; 
  }

  
}
