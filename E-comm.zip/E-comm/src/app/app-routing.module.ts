import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { PaymentComponent } from './payment/payment.component';
import { AuthGuard } from './auth.guard';
import { AdminComponent } from './admin/admin.component';
import { ProfileComponent } from './profile/profile.component';
import { AdcComponent } from './adc/adc.component';
import { ChangerComponent } from './changer/changer.component';
import { BillComponent } from './bill/bill.component';
import { WalletComponent } from './wallet/wallet.component';
import { ReviewComponent } from './review/review.component';
import { AdminGuard } from './auth/admin.guard';
import { UpdateProductComponent } from './update-product/update-product.component';
import { UpdatePDetailsComponent } from './update-pdetails/update-pdetails.component';
import { AddProductComponent } from './add-product/add-product.component';
import { ViewReviewComponent } from './view-review/view-review.component';




const routes: Routes = [
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: "cart", component: CartComponent, canActivate: [AuthGuard]
  },
  {
    path:"login", component: LoginComponent
  },
  {
    path: "register", component: RegisterComponent
  },
  {
    path: "home", component: HomeComponent, canActivate: [AuthGuard]
  },
  {
    path: "aboutUs", component: AboutUsComponent, canActivate: [AuthGuard]
  },
  {
    path: "product", component: ProductDetailsComponent, canActivate: [AuthGuard]
  },
  {
    path: "checkout", component: CheckoutComponent, canActivate: [AuthGuard]
  },
  {
    path: "productdesc", component: ProductDisplayComponent, canActivate: [AuthGuard]
  },
  {
    path: "payment", component: PaymentComponent, canActivate: [AuthGuard]
  },
  {
    path: "admin", component: AdminComponent
  },
  {
    path: "profile", component: ProfileComponent, canActivate: [AuthGuard]
  }, 
  {
    path: "adc", component: AdcComponent, canActivate: [AuthGuard]
  },
  {
    path: "change", component: ChangerComponent, canActivate: [AuthGuard]
  },
  {
    path:"bill", component: BillComponent, canActivate: [AuthGuard]
  },
  {
    path:"wallet", component: WalletComponent, canActivate: [AuthGuard]
  }, 
   {
    path: "viewProduct", component: UpdateProductComponent, canActivate: [AuthGuard]
  },
  {
    path: "upProduct", component:UpdatePDetailsComponent, canActivate: [AuthGuard]
  },
  {
    path: "addProduct", component:AddProductComponent, canActivate: [AuthGuard]
  },
  {
    path: "viewReview", component:ViewReviewComponent, canActivate: [AuthGuard]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }