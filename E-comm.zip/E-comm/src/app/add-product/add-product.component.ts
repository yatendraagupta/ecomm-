import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UpdatePserviceService } from '../update-pdetails/update-pservice.service';
import { AuthService } from '../auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  qwe: any;
  addForm:FormGroup;
  errorMessage: any;
  prod: any;

  constructor(private fb:FormBuilder, private router:Router, private ss:UpdatePserviceService,private authServe:AuthService) { }

  ngOnInit() {
    if(this.authServe.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }	
    this.addForm=this.fb.group({
      name:["",[Validators.required,Validators.pattern("([A-Za-z ]+)") ]],
      price:["",[Validators.required,Validators.min(0),Validators.pattern("[0-9]+")]],
      productId:["",[Validators.required]],
      //stock:["",[Validators.required,Validators.min(0),Validators.pattern("[0-9]+")]],
      description:["",[Validators.required,Validators.minLength(5)]],
    categoryId:[""],
    image:["",[Validators.required,Validators.pattern("[0-9]{4}(.jpg)")]]

    
      
    })
  }
  add(){
    this.qwe= JSON.parse(this.addForm.value.categoryId)
    
 this.ss.addProduct(this.addForm.value,this.qwe)
 //alert(console.log(JSON.parse(this.addForm.value.categoryId)))
 this.router.navigateByUrl('/viewProduct');

 Swal.fire({
  type: 'success',
  title: 'Product is added',
  showConfirmButton: false,
  timer: 900
})
  }
  


}
