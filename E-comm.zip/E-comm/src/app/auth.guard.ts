import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot,Router, CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { PaymentComponent } from './payment/payment.component';

@Injectable()
export class AuthGuard implements CanActivate,CanDeactivate<PaymentComponent> {
  
  canDeactivate(component: PaymentComponent, 
    route: ActivatedRouteSnapshot, 
    state: RouterStateSnapshot):  boolean {
    
    if(component.auth)
    {
      return true
    }
    else{
      this.router.navigate(['payment']);
    }

  }
  constructor(private router: Router,private auth:AuthService) {}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      if (this.auth.isLoggednIn()) {
        return true;
        }
        else{
          this.router.navigate(['login']);
          return false;
        }
  }
}

