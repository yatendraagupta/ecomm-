import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Review } from '../model/review';
import { LoginService } from '../login/login.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-view-review',
  templateUrl: './view-review.component.html',
  styleUrls: ['./view-review.component.css']
})
export class ViewReviewComponent implements OnInit {
  errorMessage: any;
  reviewForm:FormGroup;
  rev:Review[];
  flag:Boolean;
  constructor(private fb:FormBuilder,private rs:LoginService  ,private aut:AuthService) { }

  ngOnInit() {
  
    if(this.aut.sho==true){
        document.getElementById("main").style.marginLeft = "250px";
       }
       else{
        document.getElementById("main").style.marginLeft = "0";
       }

    this.reviewForm=this.fb.group({ 
        productId:["",[Validators.required,Validators.pattern("[0-9]{4}")]],
       })
  }
  getReview(){
  this.flag=true;
  
  this.rs.viewReview(this.reviewForm.value.productId)
  .then(rev => {this.rev=rev   
  })
  .catch(error => this.errorMessage = error.message);
}
}
