import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {
  obj: string;

  constructor(private aut:AuthService) { }

  ngOnInit() {
    this.obj=(sessionStorage.getItem("obj"))
   
  
    if(this.aut.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }
  }
}
