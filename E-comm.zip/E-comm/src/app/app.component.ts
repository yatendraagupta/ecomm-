import { Component } from '@angular/core';
import { LoginService } from './login/login.service';
import { CheckoutService } from './checkout/checkout.service';
import swal from 'sweetalert2';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Home';
  obj: string;
  objk: string;
  
  constructor(private rout:Router,private as : LoginService,private aut:AuthService){
    
  }
  clickMethod() {
    swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Logout!'
    }).then((result) => {
      if (result.value) {
        this.logout();
      }
    })
  }

  adminLogin(){
    this.rout.navigate(['admin']);
  }

  logout(){
    sessionStorage.clear();
    this.as.navShow=true;
    this.rout.navigate(['/login']);
  
  }

  ngOnInit() {
    this.obj=(sessionStorage.getItem("obj"))
    this.objk=(sessionStorage.getItem("username"))    
    // console.log(this.rout.url)
  // if(this.rout.url=="http://localhost:4200/product"){
  //    alert(console.log("asdfadsf"))
  //   }
  
   
}




}

