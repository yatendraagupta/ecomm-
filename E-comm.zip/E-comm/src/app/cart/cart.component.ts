import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { ProductDetailsService } from '../product-details/product-details.service';
import { IAlert, product } from '../product-details/product';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  productAddedTocart: product[];
  alerts: Array<IAlert> = [];

  allTotal: number;
  obj: string;


  constructor(private productService: ProductDetailsService, private fb: FormBuilder, private aut: AuthService) { }

  ngOnInit() {

    if (this.aut.sho == true) {
      document.getElementById("main").style.marginLeft = "250px";
    }
    else {
      document.getElementById("main").style.marginLeft = "0";
    }

    this.obj = (sessionStorage.getItem("obj"))
    this.productAddedTocart = this.productService.getProductFromCart();

    if(sessionStorage.getItem("delete")!= null){
      console.log(sessionStorage.getItem("delete")!= null);
      // this.pro1[]==this.productAddedTocart
      (this.productAddedTocart).length =0;
      sessionStorage.setItem('delete',null)
    }

    for (let i of this.productAddedTocart) {
      i.quantity = 1;
    }
    this.productService.removeAllProductFromCart();
    this.productService.addProductToCart(this.productAddedTocart);
    this.calculteAllTotal(this.productAddedTocart);
  
  }
  onAddQuantity(pro: product)
{
    this.productAddedTocart = this.productService.getProductFromCart();
    this.productAddedTocart.find(p => p.productId == pro.productId).quantity = pro.quantity + 1;
    this.productService.removeAllProductFromCart();
    this.productService.addProductToCart(this.productAddedTocart);
    this.calculteAllTotal(this.productAddedTocart);
}

onRemoveQuantity(product: product) {
    if (product.quantity > 1) {
      this.productAddedTocart = this.productService.getProductFromCart();
      this.productAddedTocart.find(p => p.productId == product.productId).quantity = product.quantity - 1;
      this.productService.removeAllProductFromCart();
      this.productService.addProductToCart(this.productAddedTocart);
      this.calculteAllTotal(this.productAddedTocart);
    }
}

  calculteAllTotal(allItems: product[]) {
    let total = 0;
    for (let i in allItems) {
      total = total + Number(allItems[i].price * allItems[i].quantity);
      
    }
    this.allTotal = total;
    sessionStorage.setItem('total', JSON.stringify(this.allTotal));
    
   
  }

  remove(prod: product) {
    this.productAddedTocart = this.productAddedTocart.filter((cart) => cart.productId != prod.productId);
    this.productService.addProductToCart(this.productAddedTocart);
    this.calculteAllTotal(this.productAddedTocart);
  }

  submit() {
    setTimeout(() => {
      this.closeAlert(this.alerts);
    }, 3000);
  }

  public closeAlert(alert: any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

  ale(){
   sessionStorage.setItem("allitem", JSON.stringify(this.productAddedTocart));
  }
}
