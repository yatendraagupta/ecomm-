import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { RegisterService } from './register.service';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import swal from 'sweetalert2';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  RegisterForm:FormGroup; 

  constructor(private fb:FormBuilder ,private rs:RegisterService,private rr:Router) { }

  ngOnInit() {
  
    if(sessionStorage.getItem('LoggedInUser')!=null)
    this.rr.navigate(['home']);

  this.RegisterForm=this.fb.group({
    name:["",[Validators.required,Validators.minLength(3),Validators.pattern("([A-Za-z]+ {0,1})+")]],
    username:["",[Validators.required,Validators.minLength(8),Validators.pattern("[A-Za-z0-9]*[@]{1}[A-Za-z0-9]*")]],
    contactNo:["",[Validators.required,Validators.pattern("[1-9][0-9]{9}")]],
    email:["",[Validators.required,Validators.pattern("[A-Za-z][\\w0-9]+@[A-Za-z]+\\.[A-Za-z]{2,3}")]],
    password:["",[Validators.required,Validators.minLength(8),Validators.pattern("[A-Za-z0-9]*[_]{1}[A-Za-z0-9]*")]]
})
  }

  register(){
    this.rs.register(this.RegisterForm.value)
      .then(res => {
        swal.fire(
          "Woohoo!",
          "Successfully Registered With Furniture-Hub",
          'success'
        )
        this.rr.navigate(['/login']);
      });
    }
  }
