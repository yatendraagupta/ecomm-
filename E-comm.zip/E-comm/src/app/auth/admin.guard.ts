import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AdminComponent } from '../admin/admin.component';
import { AdcComponent } from '../adc/adc.component';

@Injectable()
export class AdminGuard implements CanDeactivate<AdcComponent> {

  canDeactivate(component: AdcComponent, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot): boolean {
    // if(component.auth)
    // {
    //   return true
    // }
    // else{
    //   alert("pay")
    //   return false;
    // }
    return false;
  }
  
}
