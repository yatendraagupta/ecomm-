import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { product } from './product';

@Injectable()
export class ProductDetailsService {

  constructor(private http:Http) { }

  getAllProduct(){
    return this.http.get('http://localhost:8765/furn_BACKEND/FurnicoApi/productAll')
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError);
  }
  getProduct(data){
    return this.http.get('http://localhost:8765/furn_BACKEND/FurnicoApi/getProduct/'+data)
    .toPromise()
    .then(response=>response.json() as any)
    .catch(this.handleError);
  }
  
  addProductToCart(prodcuts: any) {
    localStorage.setItem("product", JSON.stringify(prodcuts));
  }
  getProductFromCart() {
    return JSON.parse(localStorage.getItem('product'));
  }
  removeAllProductFromCart() {
    return localStorage.removeItem("product");
  }

  handleError(error){
    return Promise.reject(error.json() || error);
  }

}  
