export interface product{
    productId: number;
        name: string;
        price: number;
        image: string; 
        quantity:number;
}
export class IAlert {
    id: number;
    type: string;
    message: string;
}
export class CardDetails{
    cardNumber: String;
    nameOnCard: string;
    cardType:String;
    cvv:number
    expiryMonth:number;
    expiryYear:number;
    message: string; 
}