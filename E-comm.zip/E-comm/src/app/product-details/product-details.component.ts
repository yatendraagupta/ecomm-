import { Component, OnInit, ViewChild} from '@angular/core';
import { product, IAlert } from './product';
import { ProductDetailsService } from './product-details.service';
import { CartService } from '../cart/cart.service';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { AuthService } from '../auth.service';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  errorMessage:string;
  prod : product[];
  prod1:product[];
  flag:boolean=true;
  flag1:boolean=false;
  addtocartlist:product[];
  cartItemCount: number = 0;
  alerts:Array<IAlert> = [];
  obj: string;

  re1: number =null;

  objj={
    "productId": 2101,
    	"rating":5,
    	"userId":2101,
    	"review":"nice product"

}
userI: string;
ReviewForm:FormGroup;
  asf: any;
  ppid: number;
  prod5: any;
  prid: string;
  pro: any;

  constructor(private rout:Router,private fb:FormBuilder,private rs:AuthService, private product1:ProductDetailsService,private ad:CartService, private router:Router,private aut:AuthService) { }
fun(num:any){
  this.flag=false
  this.flag1=true;
  console.log(num)
  this.product1.getProduct(num).then(response=>this.prod1=response)
}
 
fun1(){
  this.product1.getAllProduct()
    .then(res => {this.prod = res
      this.flag=true;
      this.flag1=false;
    console.log(this.prod)})
     .catch(error => {this.errorMessage = error.message; });
  }

  ngOnInit() {
    if(this.rs.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }	
    this.prid=sessionStorage.getItem('prid')
    this.ppid=JSON.parse( sessionStorage.getItem('pid'));
    this.userI=sessionStorage.getItem('useri');
    this.ReviewForm=this.fb.group({
      userId:[""],
      rating:[""],
      review:[""],
      productId:[""]
  })

    this.obj=(sessionStorage.getItem("obj"))
    this.product1.getAllProduct()
    .then(res => {this.prod = res})
     .catch(error => {this.errorMessage = error.message; }); 
     if(this.aut.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }
  }
  addtocart(product)
  {
    
      sessionStorage.removeItem("delete")
      this.addtocartlist=this.product1.getProductFromCart();
      if(this.addtocartlist==null)
      {
      
        this.addtocartlist=[];
        this.addtocartlist.push(product);
        this.product1.addProductToCart(this.addtocartlist);
        Swal.fire({
          type: 'success',
          title: 'Product is added into cart',
          showConfirmButton: false,
          timer: 900
        })
      }
      else
      {
        let tempProduct=this.addtocartlist.find(p=>p.productId==product.productId);
        if(tempProduct==null)
        {
          this.addtocartlist.push(product);
          this.product1.addProductToCart(this.addtocartlist);
          Swal.fire({        
            type: 'success',
            title: 'Product is added into cart',
            showConfirmButton: false,
            timer: 900
          })
        }
        else
        {
          Swal.fire({
            title: 'Product already exists in cart',
            animation: false,
            showConfirmButton: false,
            type:'warning',
              timer: 900
          })
        } 
      }
      this.cartItemCount=this.addtocartlist.length;
      // this.cartEvent.emit(this.cartItemCount);
       this.ad.updateCartCount(this.cartItemCount);
    }
    public closeAlert(alert:any) {
      const index: number = this.alerts.indexOf(alert);
      this.alerts.splice(index, 1);
    }


    productDesc(product){
       this.router.navigate(['productdesc'],{queryParams:{ pid: JSON.stringify(product) },skipLocationChange:true })
      }
    
getreview(){
  this.aut.getreview(this.prid)
  .then(res=>{
    this.pro=res})
  .catch(err=>err)
}

 re(i){
   this.ReviewForm.reset();
    sessionStorage.setItem('pid',i);
    this.re1=i;
 
    }


rate(){
this.ReviewForm.value.userId=JSON.parse(this.userI)
this.ReviewForm.value.rating=JSON.parse(this.ReviewForm.value.rating)
this.ReviewForm.value.productId= this.re1
this.rs.rate(this.ReviewForm.value)
.then(res=>{
  this.prod5=res
})
.catch(error => this.errorMessage = error.message);

this.sucess();

}







sucess(){
Swal.fire({   
  type: 'success',
  title: 'Submission successful',
  text: 'Thank You for the review',
  showConfirmButton: false,
    timer: 900
  })
  setTimeout(() => {
    // this.router.navigate(['/product'])
     location.reload()
  }
  , 1300);


}

}