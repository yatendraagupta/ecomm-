
import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { window } from 'rxjs/operator/window';
import swal from 'sweetalert2';


@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {
 
  AmountForm: FormGroup;
  LoginForm:FormGroup; 
  x:any;
  money: string;
  type: string;
  flag: boolean;
  number: string;
  cvv: string;
  name: string;
  card2: string;
  card3: string;
  card1: string;
  errorMessage: any;

  pro:any;
  obj: string;
  pro1:any;
  obj1: string;


  objj={
    "userId": 2101,
    "balance": 5000
}


  constructor(private fb: FormBuilder,private router:Router,private ss:AuthService) { }

  ngOnInit() {
   


    if(this.ss.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }


    this.obj=(sessionStorage.getItem("obj"))
    this.pro=sessionStorage.getItem('useri');
    this.name=(sessionStorage.getItem('name'))
    this.number=(sessionStorage.getItem('number'))
    this.cvv=(sessionStorage.getItem('cvv'))
    this.type=(sessionStorage.getItem('type'))
    this.money=(sessionStorage.getItem('money'))

    this.walletmoney()
    
    this.AmountForm=this.fb.group({
      amount:["",[Validators.required,Validators.pattern("[1-9][0-9]{1,3}")]]
    })

  }



  //show card details
  showcard(){
    this.flag=true;
  this.ss.showcard1(this.pro)
  .then(res => {
   
    this.name=res.nameOnCard
    this.cvv=res.cvv
    this.number=res.cardNumber
    this.type=res.cardType

    

    sessionStorage.setItem('card',JSON.stringify(res))
    sessionStorage.setItem('name',res.nameOnCard)
    sessionStorage.setItem('cvv',res.cvv)
    sessionStorage.setItem('number',res.cardNumber)
    sessionStorage.setItem('type',res.cardType)
  })
  .catch(error => this.errorMessage = error.message);
}


walletmoney(){
  this.objj.userId=this.pro;
  this.objj.balance=0;
  this.ss.walletmoney1(this.objj)
  .then(res1 => {
    this.money=res1.balance
    sessionStorage.setItem('money',res1.balance)
  })
  .catch(error => this.errorMessage = error.message);  
}



walletmoney11(){  
   this.objj.userId=this.pro;
   this.objj.balance=parseInt(this.AmountForm.value.amount);
   this.ss.walletmoney1(this.objj)
   .then(res1 => {
     sessionStorage.setItem('money',res1.balance)
     Swal.fire(
      'Success!',
      "Congrats!! "
      +res1.balance+
      " Is your new wallet Balance",
      'success'
    )
     this.walletmoney()
   })
   .catch(error => this.errorMessage = error.message);  
}
}