import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CheckoutService {

  constructor(private http:Http) { }


  checkout(data){
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/checkoutD",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  } 
}  
