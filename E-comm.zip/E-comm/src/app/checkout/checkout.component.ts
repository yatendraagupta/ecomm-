import { Component, OnInit } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import {CheckoutService} from './checkout.service';
import {FormGroup} from '@angular/forms';

import {Router} from '@angular/router';
import Swal from 'sweetalert2';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  
  CheckoutForm:FormGroup;
  errorMessage: any;

  objj={
    "userId": 2101,
    "name":"tuyujy",
    "email":"dgtu",
    "address":"gfijk",
    "city":"gjg",
    "state": "dgj",
    "pinCode":"324005",
    "contactNo":5454545455
}
  pro: string;
  sname: string;
  contactNo: string;
  scity: string;
  pincode: string;
  sstate: string;
  saddress: string;


  constructor(private fb:FormBuilder, private cs:CheckoutService, private router:Router  ,private aut:AuthService) { }

  ngOnInit() {
   
 
    if(this.aut.sho==true){
        document.getElementById("main").style.marginLeft = "250px";
       }
       else{
        document.getElementById("main").style.marginLeft = "0";
       }
    this.pro=sessionStorage.getItem('useri');
    this.CheckoutForm=this.fb.group({
      userId:[""],
      name:["",[Validators.required,Validators.minLength(6)]],
      email:["",[Validators.required,Validators.pattern("[A-Za-z][\\w0-9]+@[A-Za-z]+\\.[A-Za-z]+")]],
      address:["",[Validators.required]],
      city:["",[Validators.required]],
      state:["",[Validators.required]],
      pincode:["",[Validators.required,Validators.pattern("[1-9][0-9]{5}")]],
      contactNo:["",[Validators.required,Validators.pattern("[1-9]([0-9]){9}")]]
    })
  }

  checkout(){
 this.CheckoutForm.controls.userId.setValue(this.pro);
    this.cs.checkout(this.CheckoutForm.value)
    .then(res => {
      sessionStorage.setItem('sdetails',JSON.stringify(res))
      sessionStorage.setItem('sname',res.name)
      sessionStorage.setItem('saddress',res.address)
      sessionStorage.setItem('scity',res.city) 
      sessionStorage.setItem('sstate',res.state)
      sessionStorage.setItem('spincode',res.pincode)
      sessionStorage.setItem('scontactno',res.contactNo)
      Swal.fire(
        "Woohoo!",
        "Successfully Registered With Furniture-Hub",
        'success'
      )
    })
    .catch(error => this.errorMessage = error.message);
    this.router.navigate(['/payment']);
  }
}
