import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { User } from '../model/user';
import { Review } from '../model/review';

@Injectable()
export class LoginService {

  navShow : boolean =true;

  constructor(private http:Http) {
    if(sessionStorage.getItem('username')!=null)
    {
      this.navShow=false
    }
   }
  login(data){
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/Login",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }

  adminlogin(data){
    return this.http.post("http://localhost:8765/furn_BACKEND/FurnicoApi/Admin",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }

  changepass(data){
    return this.http.put("http://localhost:8765/furn_BACKEND/FurnicoApi/updatePassword",data)
    .toPromise()
    .then(Resp=>Resp.json() as any)
    .catch(error=>Promise.reject(error.json() ||error));
  }

  draw(){
    return this.http.get("http://localhost:8765/furn_BACKEND/FurnicoApi/draw")
    .toPromise()
    .then(Resp=>Resp.json())
    .catch(error=>Promise.reject(error.json() ||error));
  }


  viewUser1(){
    return this.http.get('http://localhost:8765/furn_BACKEND/FurnicoApi/userAll')
    .toPromise()
    .then(response=>response.json() as User[])
    .catch(error=>Promise.reject(error.json() ||error));
    
  }
  viewReview(data){
    return this.http.get('http://localhost:8765/furn_BACKEND/FurnicoApi/topReviews/'+data)
    .toPromise()
    .then(response=>response.json() as Review[])
    .catch(error=>Promise.reject(error.json() ||error));
    
  }


  }
