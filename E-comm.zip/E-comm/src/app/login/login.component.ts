import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { error } from 'util';
import { LoginService } from './login.service';
import { AuthService } from '../auth.service';
import Swal from 'sweetalert2';
import * as jspdf from 'jspdf';  
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  LoginForm:FormGroup; 

  email:String;
  password:String;
  successMessage:string;
  errorMessage:string;
  show_button:boolean=false;
  show_eye:boolean=false;

  
  constructor(private fb:FormBuilder,private login1:LoginService, private rout:Router,private authServe:AuthService) { }

  ngOnInit() {
    if(this.authServe.sho==true){
      document.getElementById("main").style.marginLeft = "250px";
     }
     else{
      document.getElementById("main").style.marginLeft = "0";
     }	

     
    if(sessionStorage.getItem('LoggedInUser')!=null)
      this.rout.navigate(['home']);

    this.LoginForm=this.fb.group({
      email:["",[Validators.required,Validators.email,Validators.pattern("[A-Za-z][\\w0-9]+@[A-Za-z]+\\.[A-Za-z]{2,}")]],
      password:["",[Validators.required,Validators.minLength(8),Validators.pattern("[A-Za-z0-9]*[_]{1}[A-Za-z0-9]*")]]
    })
  }
  showPassword(){
    this.show_button=!this.show_button;
    this.show_eye=!this.show_eye;
  }
  login(){
    this.login1.login(this.LoginForm.value)
    .then(res => {
      sessionStorage.setItem('user',JSON.stringify(res))
      sessionStorage.setItem('obj',res.name)
      sessionStorage.setItem('username',res.email)
      sessionStorage.setItem('useri',res.userId)
      sessionStorage.setItem('password',res.password)
      sessionStorage.setItem('name',res.name)
      this.authServe.sendToken(res.email);
      Swal.fire(
        "Woohoo! You're in",
        "Welcome "+ res.name,
        'success'
      )
      this.login1.navShow=false
      this.rout.navigate(['/home']);
    })
    .catch(error => this.errorMessage = error.message);
  }

  adminLogin(){
    this.rout.navigate(['admin']);
  }
   
  }





 


 
  
 



    
