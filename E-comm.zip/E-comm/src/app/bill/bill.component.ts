import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import * as jspdf from 'jspdf';  
import { Router } from '@angular/router';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {
 
 
  @ViewChild('content') content: ElementRef;
  name: string;
  name1: string;
  pro: string;
  sname: string;
  contactNo: string;
  scity: string;
  pincode: string;
  sstate: string;
  saddress: string;
  currentDATE: string;
  sdate: any;
  total: string;
  bitems: string;


  constructor( private router:Router) { }

ngOnInit() {

this.currentDATE = new Date().getDate()+'/'+(new Date().getMonth()+1) +'/'+new Date().getFullYear()
sessionStorage.setItem('date',this.currentDATE);
this.sdate=sessionStorage.getItem('date');
    this.sname=sessionStorage.getItem('sname');
    this.saddress=sessionStorage.getItem('saddress');
    this.scity=sessionStorage.getItem('scity');
    this.sstate=sessionStorage.getItem('sstate');
    this.pincode=sessionStorage.getItem('spincode');
    this.contactNo=sessionStorage.getItem('contactNo');
    this.name1=sessionStorage.getItem('name');
    this.total=sessionStorage.getItem('total');
    this.bitems= JSON.parse(sessionStorage.getItem('allitem'));
    sessionStorage.setItem('delete',"sdfsf")
  }
 

  invoice(){
    this.router.navigate(['/home']);
  }

//genrate $ download pdf 
  makePdf() { 
    let doc = new jspdf();
    var data = document.getElementById('contentToConvert');  
    doc.addHTML(data,function() {
      doc.save('Invoice'+'.pdf');
    });

    setTimeout(() => 
{
    this.router.navigate(['/home']);
    
},
3000);
    
}
}

