export class User{
    userId:number;
    name: string;
    username: string;
    email:string;
    contactNo:number;
}