export class AllProducts{
    productId:number;
    name:string;
    price:any;
    image:string;
    stock:number;
    description:string;
}