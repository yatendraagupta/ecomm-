export class Review{
    reviewId:number;
    rating:number;
    review:string;
    userId:number;
    productId:number;
}
